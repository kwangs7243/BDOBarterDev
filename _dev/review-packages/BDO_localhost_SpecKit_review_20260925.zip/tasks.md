# Tasks

- [ ] T001 SPEC-000~005 acceptance 및 release input을 확인한다.
- [ ] T002 runtime Tailwind CDN을 제거하고 필요한 CSS를 로컬로 묶는다.
- [ ] T003 고정 port·single instance·port conflict 처리를 구현한다.
- [ ] T004 Waitress start, health readiness와 browser open을 launcher에 연결한다.
- [ ] T005 화면 열기·정상 종료 및 pending write·scan 대기를 구현한다.
- [ ] T006 user data가 package·temporary extraction 경로 밖에 저장되는지 보장한다.
- [ ] T007 Python runtime·NumPy·Pillow·reference·templates를 package에 포함한다.
- [ ] T008 Python 미설치 Windows 및 offline package smoke test를 추가하고 실행한다.
- [ ] T009 Chrome localhost에서 저장·scan·JSON·schedule·completion·relaunch 흐름을 검증한다.
- [ ] T010 전체 필수 regression과 동일 입력 결과 비교를 실행한다.
- [ ] T011 자동 결과와 browser 결과를 분리해 기록하고 BROWSER_NOT_RUN 여부를 명시한다.
- [ ] T012 SPEC-006 acceptance 확인.
