# Tasks

- [ ] T001 기준 HTML·scanner·reference 경로를 확인한다.
- [ ] T002 기준 SHA-256과 기준 날짜를 baseline manifest에 기록한다.
- [ ] T003 reference item·icon 수와 아이콘 해시 기준을 기록한다.
- [ ] T004 보호 함수·알고리즘 및 허용 변경 범위를 기록한다.
- [ ] T005 기존 regression fixture 및 입력 목록을 기록한다.
- [ ] T006 동일 입력 비교와 정규화 규칙을 문서화한다.
- [ ] T007 Manifest의 경로·해시·fixture 참조를 기계적으로 확인한다.
- [ ] T008 SPEC-000 acceptance 확인.
